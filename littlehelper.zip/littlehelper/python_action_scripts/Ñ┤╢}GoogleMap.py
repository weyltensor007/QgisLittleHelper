import webbrowser
lon = [%x(transform( $geometry ,'EPSG:3826', 'EPSG:4326'))%]
lat = [%y(transform( $geometry ,'EPSG:3826', 'EPSG:4326'))%]
link = 'https://maps.google.com/maps?q=' + str(lat) + ',' + str(lon)
print(link)
webbrowser.open(link)