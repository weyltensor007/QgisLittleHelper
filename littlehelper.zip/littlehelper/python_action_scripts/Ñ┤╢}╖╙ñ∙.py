import os
photos = ['[%photo1_abspath%]','[%photo2_abspath%]','[%photo3_abspath%]']
for photo in photos:
	if '.jpg' in photo:
		os.startfile(photo)