import glob
from os import chdir, startfile, path
root_dir = r"R:\外來種調查資料"
chdir(root_dir)
photos = ['[%photo1%]','[%photo2%]','[%photo3%]']
photo_names = [_.split('/')[1] for _ in photos if len(_)!=0]
for _ in photo_names:
	globing = glob.glob("*/*/*/"+_) + glob.glob("*/*/*/*/"+_) + glob.glob("*/*/*/*/*/"+_)
    abspath = path.join(root_dir,globing[0])
    startfile(abspath)