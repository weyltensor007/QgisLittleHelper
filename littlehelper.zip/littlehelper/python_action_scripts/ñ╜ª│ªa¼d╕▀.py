import webbrowser
lon = [%x(transform( $geometry ,'EPSG:3826', 'EPSG:4326'))%]
lat = [%y(transform( $geometry ,'EPSG:3826', 'EPSG:4326'))%]
link ='https://maps.nlsc.gov.tw/go/'+str(lon)+'/'+str(lat)
webbrowser.open(link)